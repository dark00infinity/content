# python-start
from mishkal.tashkeel import TashkeelClass


def vocalize(text):
    vocalizer = TashkeelClass()
    return vocalizer.tashkeel(text)

# python-end
