<!-- This tracker is only for issues specific to this demo app. For example, if you have trouble
     building or running an *unmodified* copy of this app, you can report that here.

     For any other Chaquopy issues, please go to <https://github.com/chaquo/chaquopy/issues>. -->
